import React from "react";
import ProductCards from "../components/ProductCards";

const ProductsPage = () => {
    return (
        <>
        
            <ProductCards/>
        </>
    );
};

export default ProductsPage;