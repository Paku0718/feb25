export const INVALID_VALUE='Invalid Value';
export const SOMETHING_WENT_WRONG='Something went wrong';
export const WELCOME_TO_HOME='Welcome to home';